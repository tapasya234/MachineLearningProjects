Files included: 
train folder -> Contains all the ham and spam files need to train the classifier algorithm

test folder -> Contains all the ham and spam files needed to test the trained classifier.

src folder -> NaiveBayesClassifer.java; NBClassifier.java; LogisticRegressionClassifier.java; LRClassifier.java

NaiveBayesClassifier.java -> This file goes through all the files in the train folder to train the classifier using the Naive Bayes Algorithm and then goes through the test folder to predict the class of each document in that folder. 
Input - none
Output - accuracy of the algorithm

NBClassifier -> This file goes through all the files in the train folder to train the classifier using the Naive Bayes Algorithm and then goes through the test folder to predict the class of each document in that folder. This, in addition, checks if each word in the test and train data, is a stop word and if it is, that is not included in the vocabulary.
Input - none
Output - accuracy of the algorithm

LogisticRegressionClassifier.java -> This file goes through all the files in the train folder to train the classifier using the Logistic Regression Algorithm and then goes through the test folder to predict the class of each document in that folder. 
Input - none
Output - accuracy of the algorithm

LRClassifier.java -> This file goes through all the files in the train folder to train the classifier using the Logistic Regression Algorithm and then goes through the test folder to predict the class of each document in that folder. This, in addition, checks if each word in the test and train data, is a stop word and if it is, that is not included in the vocabulary.
Input - none
Output - accuracy of the algorithm


Each is a separate class of its own and has it's own main function. None of the classes use any external or third-party packages or source code in general and can be run normally. The test and train folders are a part of the folder, so no external path has been provided.
 
To execute, just compile and run that particular .java file. 
/**
 * @author Tapasya
 * Part of Project: Text Classification using Naive Bayes and Logistic Regression 
 * The main aim of this class is to train and test the Naive Bayes 
 * according to the spam and ham files given.
 */

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.HashMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;

public class NaiveBayesClassification {

	private Map<String, String> vocab = new HashMap<String, String>();	
	private Map<String, String> condProb_Ham = new HashMap<String, String>();
	private Map<String, String> condProb_Spam = new HashMap<String, String>();
	String classifier[] = {"ham","spam"};
	private float[] prior = new float[classifier.length];
	
	/*
	 * In this method, we check if the word contains any special characters
	 * If it does, it is not considered as a word.
	 */
	/*private static boolean isWord(String word){
		
		boolean result = false;
		Pattern wordPattern = Pattern.compile("\\w.");
		Matcher wordMatcher = null;
		
		wordMatcher = wordPattern.matcher(word);
		if(wordMatcher.find())
			result = true;
		else
			result = false;
		
		return result;
	}*/
	
	/*
	 * In this method, all the vocabulary from the text files in the root directory
	 * is being extracted and stored in the hashmap 'vocab'
	 * Input - root
	 */
	private Map<String, String> extractVocabulary(File root){
		
		// throws an exception if 'root' is not a directory
		if(!root.isDirectory()) {
	        throw new IllegalArgumentException(root+" is not a directory.");
	    }
		
		// Hashmap to store the complete vocabulary in the training set
		Map<String, String> words = new HashMap<String, String>();
		
		//extracting the complete list of files in 'root'
		File files[] = root.listFiles();		
		int frequency = 0; // to keep track of the number of words in the training dataset
		
		//classes to read the files
		FileReader fR = null;
		BufferedReader bR = null;
		
		// going through each file
		for(File f : files){
			
			String line;
			try {
				fR = new FileReader(f);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("File '" + f.getName() + "' not found in the directory.");
			}
			bR = new BufferedReader(fR);
			
			try {
				while((line = bR.readLine()) != null){
					String wordsInLine[] = line.split("\\s");
					
					// if the word doesn't exist in the hashmap, it will be added to it
					for(int i=0;i<wordsInLine.length;i++){
						//if(isWord(wordsInLine[i])){
							if(vocab.get(wordsInLine[i]) == null)
								frequency = 1;
							else{
								frequency = Integer.parseInt(vocab.get(wordsInLine[i]));
								frequency++;
							
							}
						//}
						vocab.put(wordsInLine[i], String.valueOf(frequency));			
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
        		try {
					fR.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error generated when closing the FileReader");
				}
        		try {
					bR.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error generated when closing the BufferedReader");
				}        		
        	} 			
		} 
		return words;
	} 
	
	/*
	 * In this method, we are calculating 
	 * the total number of documents in training dataset
	 */
	private int countDocs(File root){
		
		// throws an exception if 'root' is not a directory
		if(!root.isDirectory()) {
			throw new IllegalArgumentException(root+" is not a directory.");
		}
		
		int numOfDocs=0; // total number of documents in training dataset
		
		//extracting the complete list of files in 'root'
		File files[] = root.listFiles();
		numOfDocs = files.length;
		
		return numOfDocs;
	}
	
	/*
	 * In this method, we calculate the number of documents 
	 * of a particular classification
	 */
	private int countDocsInClass(File root, String classifier){
		
		// throws an exception if 'root' is not a directory
		if(!root.isDirectory()) {
			throw new IllegalArgumentException(root+" is not a directory.");
		}
		
		int numOfDocsInClass=0; // total number of documents in training dataset
		
		//extracting the complete list of files in 'root'
		File files[] = root.listFiles();	
	
		// creating pattern for the regular expression developed
        Pattern pattern = Pattern.compile(classifier);
        
        // creating Matcher classes to check if the pattern matches
        Matcher matcher;
        
		// going through each filename to classify them into spam and ham
		for(File f : files){
			matcher = pattern.matcher(f.getName());
			
			if(matcher.find())
				numOfDocsInClass++;			
		}
		return numOfDocsInClass;
	}
	
	/*
	 * In this method, we extract all the words in all the text files 
	 * of a particular classification and compile then into one hashmap
	 * The HashMap will contain the following
	 * key - word   Value - frequency of the word in that class
	 */
	private Map<String, String> concatenateTextOfClass(File root, String classifier){
		// throws an exception if 'root' is not a directory
		if(!root.isDirectory()) {
	        throw new IllegalArgumentException(root+" is not a directory.");
	    }
	    	    
	    // extracting the complete list of files in the folder root
	    File[] files = root.listFiles();
	    FileReader fR = null;
	    BufferedReader bR = null;
        String fileName = null;
        int numberOfWords = 0;
               
        Map<String, String> words = new HashMap<String, String>();
        // checking if file name matches our regular expression pattern
        Pattern pattern = Pattern.compile(classifier);
        Matcher matcher = null;
        
        // checking if each file matches the regular expression 
        for (File f : files) {

            fileName = f.getName();
            matcher = pattern.matcher(fileName);
            
            // if it matches, updating the HashMap wit respect to the words in the file
            String line;
            if (matcher.find()) {
            	
            	try{            		
            		fR = new FileReader(f);
            		bR = new BufferedReader(fR);
            		
            		while((line=bR.readLine()) != null){
            			String wordsInLine[] = line.split("\\s");
    					
    					for(int j=0;j<wordsInLine.length;j++){
    						//if(isWord(wordsInLine[j])){
    							if(words.get(wordsInLine[j]) == null)
    								numberOfWords = 1;
    							else{
    								numberOfWords = Integer.parseInt(words.get(wordsInLine[j]));
    								numberOfWords++;
    							
    							}
    						//}
    						words.put(wordsInLine[j], String.valueOf(numberOfWords));
    						
    					}
            		}
            		
            	}
            	catch(IOException e){
            		e.printStackTrace();
            		System.out.println("Problem reading the file");
            	}
            	finally{
            		try {
						fR.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						System.out.println("Error generated when closing the FileReader");
					}
            		try {
						bR.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						System.out.println("Error generated when closing the BufferedReader");
					}
            		
            	}

            }
        }
        return words;
    							
	}
	
	/*
	 * In this method, we find the frequency of specified word 
	 * in a particular classification
	 */
	/*private int calcFrequency(Map<String, String> words, String t){
		int frequency = 0;
		for(Object key : words.keySet()){
			String term = words.get(key);
			if(term.equalsIgnoreCase(t))
				frequency++;
		}
		return frequency;
	}*/
	
	/*
	 * In this method, we calculate the conditional probability of each word
	 * with the help of one-plus laplace smoothing and 
	 * calculations are done in log-scale to overcome underflow.
	 * Output - Conditional Probability
	 * In classification, 0 - Ham, 1 - Spam
	 * Input - Root directory
	 */
	public void trainNB(File root){
		
		vocab = extractVocabulary(root);
		int numOfDocs = countDocs(root);
				
		for(int i=0;i<classifier.length;i++){
			int numOfDocsInClass = countDocsInClass(root, classifier[i]);
			prior[i] = (float)numOfDocsInClass/numOfDocs;
			
			Map<String, String> wordsInClass = new HashMap<String, String>();
			wordsInClass = concatenateTextOfClass(root, classifier[i]);
			
			// calculating the total number of words in a class
			int totalFrequency = 0;
			for(Object key : wordsInClass.keySet()){
				String term = wordsInClass.get(key);
				totalFrequency += Integer.parseInt(term);
			}
			
			float denominator = totalFrequency + wordsInClass.size();
			float numerator = 0;
			if(i == 0){
				for(Object key : wordsInClass.keySet()){
						numerator = Float.parseFloat(wordsInClass.get(key))+1;
						double prob = numerator/denominator;
						condProb_Ham.put(String.valueOf(key),String.valueOf(prob));
				}
			}
			else{
				for(Object key : wordsInClass.keySet()){
						numerator = Float.parseFloat(wordsInClass.get(key))+1;
						double prob = numerator/denominator;
						condProb_Spam.put(String.valueOf(key),String.valueOf(prob));
				}
			}
				
		}
	}
	
	/*
	 * In this method, we extract the tokens that are present
	 * in the vocabulary and the file 'f' passed as argument
	 */
	private Map<String, String> extractTokensFromDoc(File f){
		Map<String, String> words = new HashMap<String, String>();
		
		// classes to read the file
		FileReader fR = null;
		try {
			fR = new FileReader(f);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		BufferedReader bR = new BufferedReader(fR);
		String line;
		int numOfWords = 0;
		
		try {
			while((line = bR.readLine())!=null){
				String wordsInLine[] = line.split("\\s");
				
				for(int i=0;i<wordsInLine.length;i++){
					// checking if it already exists in vocab
					if(words.get(wordsInLine[i]) == null)
						numOfWords = 1;
					else{
						numOfWords = Integer.parseInt(words.get(wordsInLine[i]));
						numOfWords++;
					
					}
				//}
				words.put(wordsInLine[i], String.valueOf(numOfWords));
				
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return words;
	}
	
	/*
	 * In this method, we test the algorithm we have developed and
	 * ask it to classify a file passed as an argument either as "Spam" or "Ham"
	 */
	public String applyNB(File f){
		Map<String, String> wordsInDoc = new HashMap<String, String>();
		wordsInDoc = extractTokensFromDoc(f);
		
		double[] score = new double[classifier.length];
		for(int i=0;i<classifier.length;i++){
			score[i] = Math.log(prior[i]);
			
			if(i==0){
				for(Object key : wordsInDoc.keySet()){
					String prob = condProb_Ham.get(key);
					double condProb=0.0;
					if(prob == null){
						double p = 1/(vocab.size()+condProb_Ham.size());
						condProb = Math.log(p);
					}						
					else
						condProb = Math.log(Double.parseDouble(prob));
					score[i] += condProb;
				}
			}
			
			if(i==1){
				for(Object key : wordsInDoc.keySet()){
					String prob = condProb_Spam.get(key);
					double condProb=0.0;
					if(prob == null){
						double p = 1/(vocab.size()+condProb_Spam.size());
						condProb = Math.log(p);
					}
					else
						condProb = Math.log(Double.parseDouble(prob));
					score[i] += condProb;
				}
			}
				
		}
		
		if(score[0] >= score[1])
			return "Ham";
		else
			return "Spam";
	}

	/*
	 * In this method, we test the accuracy of the Naive Bayes algorithm
	 * by asking it to classify each file that we have in testing dataset
	 * and check if it has classified it correctly
	 */
	public float calculateAccuracy(File root){
		float accuracy = 0;
		
		// throws an exception if 'root' is not a directory
		if(!root.isDirectory()) {
		    throw new IllegalArgumentException(root+" is not a directory.");
		}
		
		// creating pattern for the regular expression developed
		Pattern patternHam = Pattern.compile(classifier[0]);
        Pattern patternSpam = Pattern.compile(classifier[1]);
        
        // creating Matcher classes to check if the pattern matches
        Matcher matcher;
		
        // String to check the accuracy
        String prediction = null, correct = null;
		// listing all the files in the directory 'root'
		File[] files = root.listFiles();
		for(int i=0;i<files.length;i++){
			prediction = applyNB(files[i]);
			
			
			// going through filename to classify them into spam and ham
			matcher = patternHam.matcher(files[i].getName());			
			if(matcher.find())
				correct = "Ham";
			matcher = patternSpam.matcher(files[i].getName());			
			if(matcher.find())
				correct = "Spam";
			
			if(prediction.equalsIgnoreCase(correct))
				accuracy++;
		}
		
		//calculating the accuracy
		accuracy = (accuracy/files.length)*100;
		return accuracy;
	}
	
	public static void main(String[] args){
		
		NaiveBayesClassification textClassifier = new NaiveBayesClassification();
		
		// defining the directories of the training dataset and testing dataset
		File trainRoot = new File("train");
		File testRoot = new File("test");
		
		textClassifier.trainNB(trainRoot);
		System.out.println("Accuracy of Naive Bayes Text Classification Algorithm ");
		float accuracy = textClassifier.calculateAccuracy(trainRoot);
		System.out.println("Training Dataset: " + accuracy + "%");
		accuracy = textClassifier.calculateAccuracy(testRoot);
		System.out.println("Testing Dataset: " + accuracy + "%");
		
	}
}

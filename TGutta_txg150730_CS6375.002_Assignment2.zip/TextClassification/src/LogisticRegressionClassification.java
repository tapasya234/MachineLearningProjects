import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Tapasya
 * Part of Project: Text Classification using Naive Bayes and Logistic Regression 
 * The main aim of this class is to train and test the Logistic Regression 
 * according to the spam and ham files given.
 */
public class LogisticRegressionClassification {

	private Map<String, String> vocab = new HashMap<String, String>();	
	String classifier[] = {"ham","spam"};
	private Map<String, String> weight = new HashMap<String, String>();
	int[][] freq;
	
	/*
	 * In this method, we check if the word contains any special characters
	 * If it does, it is not considered as a word.
	 */
	private static boolean isWord(String word){
		
		boolean result = false;
		Pattern wordPattern = Pattern.compile("\\w.");
		Matcher wordMatcher = null;
		
		wordMatcher = wordPattern.matcher(word);
		if(wordMatcher.find())
			result = true;
		else
			result = false;
		
		return result;
	}
	
	/*
	 * In this method, we calculate the sigmoid value of the parameter
	 */
	private double calcSigmoid(double x){
		double value = 1/(1+Math.exp(-1*x));
		return value;
	}
	
	/*
	 * In this method, all the vocabulary from the text files in the root directory
	 * is being extracted and stored in the hashmap 'vocab'
	 * Input - root
	 */
	private Map<String, String> extractVocabulary(File root){
		
		// throws an exception if 'root' is not a directory
		if(!root.isDirectory()) {
	        throw new IllegalArgumentException(root+" is not a directory.");
	    }
		
		// Hashmap to store the complete vocabulary in the training set
		Map<String, String> words = new HashMap<String, String>();
		
		//extracting the complete list of files in 'root'
		File files[] = root.listFiles();		
		int numOfWords = 0; // to keep track of the number of words in the training dataset
		
		//classes to read the files
		FileReader fR = null;
		BufferedReader bR = null;
		
		// going through each file
		for(File f : files){
			
			String line;
			try {
				fR = new FileReader(f);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("File '" + f.getName() + "' not found in the directory.");
			}
			bR = new BufferedReader(fR);
			
			try {
				while((line = bR.readLine()) != null){
					String wordsInLine[] = line.split("\\s");
					
					// if the word doesn't exist in the hashmap, it will be added to it
					for(int i=0;i<wordsInLine.length;i++){
						if(words.get(wordsInLine[i]) == null)
							//frequency = 1;
							words.put(String.valueOf(numOfWords++), wordsInLine[i]);
							//words.put(String.valueOf(numOfWords++), wordsInLine[i]);
						/*else{
    						frequency = Integer.parseInt(words.get(wordsInLine[i]));
    						frequency++;    							
    					}
    					words.put(wordsInLine[i], String.valueOf(frequency));	*/				
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
        		try {
					fR.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error generated when closing the FileReader");
				}
        		try {
					bR.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error generated when closing the BufferedReader");
				}        		
        	} 			
		} 
		return words;
	} 

	/*
	 * In this method, we initialze the data[][] as follows
	 * freq[i][0] - 1; It is the bias
	 * freq[i][j] - Frequency of word j in document i
	 * freq[i][n+1] - Class of document i - Ham/Spam
	 */
	private void calcFrequency(File root){
		// throws an exception if 'root' is not a directory
		if(!root.isDirectory()) {
			throw new IllegalArgumentException(root+" is not a directory.");
		}
			
		int numOfWords = vocab.size();
		//extracting the complete list of files in 'root'
		File files[] = root.listFiles();	
				
		// creating pattern for the regular expression developed
		Pattern patternHam = Pattern.compile(classifier[0]);
		Pattern patternSpam = Pattern.compile(classifier[1]);
		    
		int classification = 0;
		// creating Matcher classes to check if the pattern matches
		Matcher matcher;
		
		freq = new int[files.length][numOfWords+2];
		
		for(int i = 0; i<files.length;i++){
			// going through filename to classify them into spam and ham
			matcher = patternHam.matcher(files[i].getName());			
			if(matcher.find())
				classification = 0; // 0 - Ham
			matcher = patternSpam.matcher(files[i].getName());			
			if(matcher.find())
				classification = 1; // 1 - Spam
			
			System.out.println("Extracting vocabulary of File " + (i+1));
			for(int j=0;j<vocab.size()+2;j++){
				if(j==0)
					freq[i][0] = 1;
				else if(j == numOfWords+1)
					freq[i][j] = classification;
				else{
			
					// calculating frequency of the word in document i
					String word = vocab.get(String.valueOf(i));
					freq[i][j] = calcFreqInFile(word,files[i]);
				}
			}
		} 
		
		for(int j=0;j<vocab.size()+2;j++)
			System.out.println(freq[0][j]);
	}
	
	private int calcFreqInFile(String word, File f){
		int freq = 0;
		
		// classes to read the file
		FileReader fR = null;
		BufferedReader bR = null;
		try {
			fR= new FileReader(f);
			bR= new BufferedReader(fR);
			String line = null;
			
			while((line=bR.readLine())!= null){
				String wordsInLine[] = line.split("\\s");
				for(String term: wordsInLine){
					if(term.equalsIgnoreCase(word))
						freq++;
				}
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				fR.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				bR.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return freq;
	}
	
	/*
	 * In this method, we initialize the weight map
	 */
	private void initializeWeights(){
		for(Object key: vocab.keySet()){
			weight.put(String.valueOf(vocab.get(key)),String.valueOf(0));
		}
	}
		
	
	/*
	 * In this method, we predict the probability of a particular file
	 * with the help of the weights at that particular moment
	 */
	private double predictClass(File file){
		double prob = 0.0;
		
		// extracting the words in file f
		Map<String, String> words = new HashMap<String, String>();
		words = extractTokensFromFile(file);
		// calculate the sum of the weight of each word that occurs in words
		double sum = 0.0;
		double w = 0.0;
		for(Object key: words.keySet()){
			//extracting the weight of that particular word
			if(weight.containsKey(key)){
				w = Double.parseDouble(String.valueOf(weight.get(key))); 
			}
			
			//exrtacting the frequency of that particular word
			double f = Integer.parseInt(String.valueOf(words.get(key))); 
			sum = sum + (w * f); 
		}
		
		// invoking the sigmoid function on sum
		prob = calcSigmoid(sum);
		return prob;
	}
		
	/*
	 * In this method, we extract the tokens that are present
	 * in the vocabulary and the file 'f' passed as argument
	 */
	private Map<String, String> extractTokensFromFile(File f){
		Map<String, String> words = new HashMap<String, String>();
		
		// classes to read the file
		FileReader fR = null;
		try {
			fR = new FileReader(f);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		BufferedReader bR = new BufferedReader(fR);
		String line;
		int numOfWords = 0;
		
		try {
			while((line = bR.readLine())!=null){
				String wordsInLine[] = line.split("\\s");
				
				for(int i=0;i<wordsInLine.length;i++){
					// checking if it already exists in vocab
					if(words.get(wordsInLine[i]) == null)
						numOfWords = 1;
					else{
						numOfWords = Integer.parseInt(words.get(wordsInLine[i]));
						numOfWords++;
					
					}
				//}
				words.put(wordsInLine[i], String.valueOf(numOfWords));
				
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return words;
	}
	
	/*
	 * In this method, we are calculating 
	 * the total number of documents in training dataset
	 */
	private int countDocs(File root){
		
		// throws an exception if 'root' is not a directory
		if(!root.isDirectory()) {
			throw new IllegalArgumentException(root+" is not a directory.");
		}
		
		int numOfDocs=0; // total number of documents in training dataset
		
		//extracting the complete list of files in 'root'
		File files[] = root.listFiles();
		numOfDocs = files.length;
		
		return numOfDocs;
	}
	
	/*
	 * In this method, we calculate the weight of each word
	 * by using the MCAP logistic regression formula with L2 regularization, i.e.,
	 * -y * (log(P(Y=1|X,w)) - (1-y) * log(P(Y=0|X,w))
	 * We are hardcoding the values of 
	 * eta - leerning rate and lamba - regularization constant
	 * The number of times we are running the loop to train the data is 
	 */
	private void trainLR(File root){
		
		// throws an exception if 'root' is not a directory
		if(!root.isDirectory()) {
			throw new IllegalArgumentException(root+" is not a directory.");
		}
		
		vocab = extractVocabulary(root);
		initializeWeights();
		calcFrequency(root);
		double eeta = 0.1; // eeta is the learning rate
		double lambda = 0.005; // lambda is the regression factor 
		
		int numOfWords = vocab.size();
		Map<String, String> prediction = new HashMap<String, String>();
		double[] dw = new double[numOfWords];
		
		File files[] = root.listFiles();
		
		// words in Ham
		/*Map<String, String> words_Ham = new HashMap<String, String>();
		words_Ham = concatenateTextOfClass(root, classifier[0]);
		
		// words in Spam
		Map<String, String> words_Spam = new HashMap<String, String>();
		words_Spam = concatenateTextOfClass(root, classifier[1]);*/
		
		// running in the loop for 200 times
		for(int k = 0;k<20;k++){
			
			System.out.println(k);
			// predicting the class of all the files
			
			for(File f: files){
				double p = predictClass(f);
				prediction.put(f.getName(), String.valueOf(p));
			}
			
			// initializing dw[i] to 0
			for(int i=0;i<numOfWords;i++){
				dw[i] = 0;
			}
			
			for(int i=0;i<numOfWords;i++){
				for(int j=0;j<countDocs(root);j++){
					double p = Double.parseDouble(String.valueOf(prediction.get(files[i].getName())));
					dw[i] = dw[0] + freq[j][i+1] * (freq[j][numOfWords+1] - p);
				}
			}
			
			for(int i=0;i<numOfWords;i++){
				double w = Integer.parseInt(String.valueOf(weight.get(vocab.get(i))));
				w = w + eeta * (dw[i] - lambda * w);				
			}
		}
	}
	
	private String applyLR(File f){
		
		double prediction = predictClass(f);
		if(prediction > .5)
			return classifier[0];
		else
			return classifier[1];
		
	}
	

	/*
	 * In this method, we test the accuracy of the Naive Bayes algorithm
	 * by asking it to classify each file that we have in testing dataset
	 * and check if it has classified it correctly
	 */
	public float calculateAccuracy(File root){
		float accuracy = 0;
		
		// throws an exception if 'root' is not a directory
		if(!root.isDirectory()) {
		    throw new IllegalArgumentException(root+" is not a directory.");
		}
		
		// creating pattern for the regular expression developed
		Pattern patternHam = Pattern.compile(classifier[0]);
        Pattern patternSpam = Pattern.compile(classifier[1]);
        
        // creating Matcher classes to check if the pattern matches
        Matcher matcher;
		
        // String to check the accuracy
        String prediction = null, correct = null;
		// listing all the files in the directory 'root'
		File[] files = root.listFiles();
		for(int i=0;i<files.length;i++){
			prediction = applyLR(files[i]);
			
			
			// going through filename to classify them into spam and ham
			matcher = patternHam.matcher(files[i].getName());			
			if(matcher.find())
				correct = "Ham";
			matcher = patternSpam.matcher(files[i].getName());			
			if(matcher.find())
				correct = "Spam";
			
			if(prediction.equalsIgnoreCase(correct))
				accuracy++;
		}
		
		//calculating the accuracy
		accuracy = (accuracy/files.length)*100;
		return accuracy;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LogisticRegressionClassification textClassifier = new LogisticRegressionClassification();
		
		
		// defining the directories of the training dataset and testing dataset
		File trainRoot = new File("train");
		File testRoot = new File("test");
		
		//
		/*textClassifier.initializeWeights();
		textClassifier.vocab = textClassifier.extractVocabulary(trainRoot);
		textClassifier.calcFrequency(trainRoot);*/
		
		System.out.println("Before training");
		textClassifier.trainLR(trainRoot);
		System.out.println("After training");
		System.out.println("Accuracy of Logistic Regression Text Classification Algorithm ");
		float accuracy = textClassifier.calculateAccuracy(trainRoot);
		System.out.println("Training Dataset: " + accuracy + "%");
		accuracy = textClassifier.calculateAccuracy(testRoot);
		System.out.println("Testing Dataset: " + accuracy + "%");
		
		
		
	}

}

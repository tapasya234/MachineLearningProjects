import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Tapasya
 *
 */
public class Perceptron {

	private HashMap<String, Double> vocab = new HashMap<String, Double>();	
	private HashMap<String, Integer> weights = new HashMap<String, Integer>();	
	private List<String> stopWords = new ArrayList<String>();
	double eta = 1.00;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Perceptron textClassifier = new Perceptron();
		
		// defining the directories of the training dataset and testing dataset
		File trainRoot = new File("train");
		File testRoot = new File("test");
		
		System.out.println("Accuracy of Perceptron Text Classification Algorithm ");
		textClassifier.trainPerceptron(trainRoot);
		float accuracy = textClassifier.calculateAccuracy(trainRoot);
		System.out.println("Training Dataset: " + accuracy + "%");
		accuracy = textClassifier.calculateAccuracy(testRoot);
		System.out.println("Testing Dataset: " + accuracy + "%");
		
		System.out.println("Accuracy of Perceptron Text Classification Algorithm(excluding stop words)");
		textClassifier.extractStopWords();
		textClassifier.trainPerceptronWOStopWords(trainRoot);
		accuracy = textClassifier.calculateAccuracy(trainRoot);
		System.out.println("Training Dataset: " + accuracy + "%");
		accuracy = textClassifier.calculateAccuracy(testRoot);
		System.out.println("Testing Dataset: " + accuracy + "%");
		
	}
	
	/*
	 * In this method, all the stop words that have been taken from 
	 * the URL "http://www.ranks.nl/stopwords" has been stored in file stopWords.txt
	 * will be extracted from it and stored in the array stopWords[]
	 */
	private void extractStopWords(){
		
		File f = new File("stopWords.txt");
		FileReader fR = null;
		BufferedReader bR = null;
		try {
			fR = new FileReader(f);
			bR = new BufferedReader(fR);
			String line=null;
			while((line = bR.readLine()) != null){
				line = line.trim();
				stopWords.add(line);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
    		try {
				fR.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Error generated when closing the FileReader");
			}
    		try {
				bR.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Error generated when closing the BufferedReader");
			}        		
    	} 
				
	}
	
	/* 
	 * In this method, we are checking if each word is a stop word
	 * and if it isn't it is being added to our vobad list
	 */
	private boolean checkIfStopWord(String term){
		boolean isStopWord = false;
		
		for(String word: stopWords){
			if(word.equalsIgnoreCase(term)){
				isStopWord = true;
				break;
			}
		}
		return isStopWord;
	}
	
	/*
	 * In this method, we calculate the conditional probability of each word
	 * with the help of one-plus laplace smoothing and 
	 * calculations are done in log-scale to overcome underflow.
	 * Output - Conditional Probability
	 * In classification, 0 - Ham, 1 - Spam
	 * Input - Root directory
	 */
	private void trainPerceptron(File rootFolder){
	
		// throws an exception if 'root' is not a directory
		if(!rootFolder.isDirectory()) {
		      throw new IllegalArgumentException(rootFolder +" is not a directory.");
		}
				
		vocab = extractVocabulary(rootFolder);
		int iterations = 1000;
		
		for(int i=0;i<iterations;i++){
			//extracting the complete list of files in 'root'
			File files[] = rootFolder.listFiles();		
			
			// going through each file
			for(File f : files){
				
				// creating pattern for the regular expression developed
				Pattern patternHam = Pattern.compile("ham");
		        Pattern patternSpam = Pattern.compile("spam");
		        
		        // creating Matcher classes to check if the pattern matches
		        Matcher matcher;
			
		        int t=0; // expected output
		        matcher = patternHam.matcher(f.getName());			
				if(matcher.find())
					t = 1;
				matcher = patternSpam.matcher(f.getName());			
				if(matcher.find())
					t = -1;
				
				// vocabulary in file f
				HashMap<String, Integer> featureSet = extractFeatureSet(f);
				int o = predictFile(featureSet); // actual output
				
				// if expected output is not the same as actual output, update the weights
				if(t != o) {
					updateWeights(featureSet, t, o);
				}
			}
		}
		
	}

	/*
	 * In this method, all the vocabulary from the text files in the root directory
	 * is being extracted and stored in the hashmap 'vocab'.
	 * This hashmap also stores the weights of each word
	 * Input - root
	 */
	private HashMap<String, Double> extractVocabulary(File rootFolder){
		if(!rootFolder.isDirectory()) {
	        throw new IllegalArgumentException(rootFolder +" is not a directory.");
	    }
		
		// Hashmap to store the complete vocabulary in the training set
		HashMap<String, Double> words = new HashMap<String, Double>();
		
		//extracting the complete list of files in 'root'
		File files[] = rootFolder.listFiles();		
		
		//classes to read the files
		FileReader fR = null;
		BufferedReader bR = null;
		
		// going through each file
		for(File f : files){
			
			String line;
			try {
				fR = new FileReader(f);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("File '" + f.getName() + "' not found in the directory.");
			}
			bR = new BufferedReader(fR);
			
			try {
				while((line = bR.readLine()) != null){
					String wordsInLine[] = line.split("\\s");
					
					// if the word doesn't exist in the hashmap, it will be added to it
					for(int i=0;i<wordsInLine.length;i++){
						//if(isWord(wordsInLine[i])){
							if(words.get(wordsInLine[i]) == null)
								words.put(wordsInLine[i], 0.1);			
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
        		try {
					fR.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error generated when closing the FileReader");
				}
        		try {
					bR.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error generated when closing the BufferedReader");
				}        		
        	} 			
		} 		
		return words;
	}
	
	/*
	 * In this method, we are extracting all the words in the file passed as parameter
	 * Input - File f
	 */
	private HashMap<String, Integer> extractFeatureSet(File f){
		HashMap<String, Integer> featureSet = new HashMap<String, Integer>();
		
		FileReader fR ;
		BufferedReader bR;
		int numOfWords = 0;
				
		try {
			fR = new FileReader(f);
			bR = new BufferedReader(fR);
			
			String line;
			while((line = bR.readLine()) != null){
				String[] wordsInLine = line.split("\\s");
				for(int i=0;i<wordsInLine.length;i++){
					// checking if it already exists in vocab
					if(featureSet.get(wordsInLine[i]) == null)
						numOfWords = 1;
					else{
						numOfWords = featureSet.get(wordsInLine[i]);
						numOfWords++;
					}
					featureSet.put(wordsInLine[i], numOfWords);
				}
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return featureSet;
	}
	
	/*
	 * In this method, we are updating the values of the weights 
	 * in relation with a particular feature if it's expected output 
	 * is not equal to the derived output.
	 */
	private void updateWeights(HashMap<String, Integer>featureSet, int t, int o){
		
		for(String key: featureSet.keySet()){
			double value = featureSet.get(key);
			double delta = eta * ( t - o) * value;
			double weight = vocab.get(key);
			weight = weight + delta;
			vocab.put(key, weight);
		}
	}

	/*
	 * In this method, we classify a file based on the feature set passed as parameter
	 */
	private int predictFile(HashMap<String, Integer> featureSet){
		int output;
		
		double score = 0.0;
		for(String key: featureSet.keySet()){
			
			if(vocab.containsKey(key)){
				score = score + (featureSet.get(key) * vocab.get(key));
			}
		}
		
		if(score >= 0)
			output = 1;
		else
			output = -1;
		
		return output;
	}

	/*
	 * In this method, we test the accuracy of the Perceptron algorithm
	 * by asking it to classify each file that we have in testing dataset
	 * and check if it has classified it correctly
	 */
	public float calculateAccuracy(File rootFolder){
		
		float accuracy = 0;
		
		// throws an exception if 'root' is not a directory
		if(!rootFolder.isDirectory()) {
		    throw new IllegalArgumentException(rootFolder+" is not a directory.");
		}
		
		// creating pattern for the regular expression developed
		Pattern patternHam = Pattern.compile("ham");
        Pattern patternSpam = Pattern.compile("spam");
        
        // creating Matcher classes to check if the pattern matches
        Matcher matcher;
		
        // expected output
        int t=0;
        //Obtained output
        int o;
		// listing all the files in the directory 'root'
		File[] files = rootFolder.listFiles();
		for(int i=0;i<files.length;i++){
			HashMap<String, Integer> featureSet = extractFeatureSet(files[i]);
			o = predictFile(featureSet);
						
			// going through filename to classify them into spam and ham
			matcher = patternHam.matcher(files[i].getName());			
			if(matcher.find())
				t = 1;
			matcher = patternSpam.matcher(files[i].getName());			
			if(matcher.find())
				t = -1;
			
			if(t == o)
				accuracy++;
			
			//System.out.println(files[i] + " " + t + " " + o + " " + accuracy);
		}
		
		//calculating the accuracy
		accuracy = (accuracy/files.length)*100;
		return accuracy;
	}

	/*
	 * In this method, all the vocabulary, except stop words from the text files in the root directory
	 * is being extracted and stored in the hashmap 'vocab'.
	 * This hashmap also stores the weights of each word
	 * Input - root
	 */
	private HashMap<String, Double> extractVocabularyWOStopWords(File rootFolder){
		if(!rootFolder.isDirectory()) {
	        throw new IllegalArgumentException(rootFolder +" is not a directory.");
	    }
		
		// Hashmap to store the complete vocabulary in the training set
		HashMap<String, Double> words = new HashMap<String, Double>();
		
		//extracting the complete list of files in 'root'
		File files[] = rootFolder.listFiles();		
		
		//classes to read the files
		FileReader fR = null;
		BufferedReader bR = null;
		
		// going through each file
		for(File f : files){
			
			String line;
			try {
				fR = new FileReader(f);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("File '" + f.getName() + "' not found in the directory.");
			}
			bR = new BufferedReader(fR);
			
			try {
				while((line = bR.readLine()) != null){
					String wordsInLine[] = line.split("\\s");
					
					// if the word doesn't exist in the hashmap, it will be added to it
					for(int i=0;i<wordsInLine.length;i++){
						if(!checkIfStopWord(wordsInLine[i])){
							if(words.get(wordsInLine[i]) == null)
								words.put(wordsInLine[i], 0.1);	
						}
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
        		try {
					fR.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error generated when closing the FileReader");
				}
        		try {
					bR.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Error generated when closing the BufferedReader");
				}        		
        	} 			
		} 		
		return words;
	}


	/*
	 * In this method, we are extracting all the words in the file passed as parameter
	 * Input - File f
	 */
	private HashMap<String, Integer> extractFeatureSetWOStopWords(File f){
		HashMap<String, Integer> featureSet = new HashMap<String, Integer>();
		
		FileReader fR ;
		BufferedReader bR;
		int numOfWords = 0;
				
		try {
			fR = new FileReader(f);
			bR = new BufferedReader(fR);
			
			String line;
			while((line = bR.readLine()) != null){
				String[] wordsInLine = line.split("\\s");
				for(int i=0;i<wordsInLine.length;i++){
					// checking if it already exists in vocab
					if(!checkIfStopWord(wordsInLine[i])){
						if(featureSet.get(wordsInLine[i]) == null)
							numOfWords = 1;
						else{
							numOfWords = featureSet.get(wordsInLine[i]);
							numOfWords++;
						}
						featureSet.put(wordsInLine[i], numOfWords);
					}
				}
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return featureSet;
	}
	
	/*
	 * In this method, we calculate the conditional probability of each word
	 * with the help of one-plus laplace smoothing and 
	 * calculations are done in log-scale to overcome underflow.
	 * Output - Conditional Probability
	 * In classification, 0 - Ham, 1 - Spam
	 * Input - Root directory
	 */
	private void trainPerceptronWOStopWords(File rootFolder){
	
		// throws an exception if 'root' is not a directory
		if(!rootFolder.isDirectory()) {
		      throw new IllegalArgumentException(rootFolder +" is not a directory.");
		}
				
		vocab = extractVocabularyWOStopWords(rootFolder);
		int iterations = 1000;
		
		for(int i=0;i<iterations;i++){
			//extracting the complete list of files in 'root'
			File files[] = rootFolder.listFiles();		
			
			// going through each file
			for(File f : files){
				
				// creating pattern for the regular expression developed
				Pattern patternHam = Pattern.compile("ham");
		        Pattern patternSpam = Pattern.compile("spam");
		        
		        // creating Matcher classes to check if the pattern matches
		        Matcher matcher;
			
		        int t=0; // expected output
		        matcher = patternHam.matcher(f.getName());			
				if(matcher.find())
					t = 1;
				matcher = patternSpam.matcher(f.getName());			
				if(matcher.find())
					t = -1;
				
				// vocabulary in file f
				HashMap<String, Integer> featureSet = extractFeatureSetWOStopWords(f);
				int o = predictFile(featureSet); // actual output
				
				// if expected output is not the same as actual output, update the weights
				if(t != o) {
					updateWeights(featureSet, t, o);
				}
			}
		}
		
	}
}

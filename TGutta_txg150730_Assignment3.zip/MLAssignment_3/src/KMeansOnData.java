import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;

/**
 * @author Tapasya
 * The class is to test K-Means algorithm for a dataset 
 * Input: Dataset, number of clusters 'k'
 * Output: Mean of the clusters
 */
public class KMeansOnData {

	private int MAX_ITERATIONS;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		KMeansOnData obj = new KMeansOnData();
		obj.MAX_ITERATIONS = 100;
		File f = new File("crime_data.csv");
		float data[] = obj.extractData(f);
		
		
	}
	
	private float[] extractData(File f){
		float[] data = new float[50];
		
		FileReader fR;
		BufferedReader bR ;
		try {
			fR = new FileReader(f);
			bR = new BufferedReader(fR);
			
			bR.readLine();
			String line;
			
			int count=0;
			while((line = bR.readLine())!= null){
				String wordsInLine[] = line.split(",");
				data[count++] = Float.parseFloat(wordsInLine[wordsInLine.length-1]);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return data;
	}
	private float[] getRandomCentroids(float[] data,int k){
		float[] centroids = new float[k];
		
		int min = 0; // used to generate a random number
		int max = data.length - 1; // used to generate a random number
		int random;
		for(int i=0;i<k;i++){
			random = min + (int)(Math.random() * (max-min + 1));
			centroids[i] = random;
		}
		return centroids;
	}
	
	private boolean shouldStop(float[] oldCentroids, float[] centroids, int iterations){
		boolean result = true;
		
		// checking it number of iterations have exceeded the max interations allowed
		if(iterations > MAX_ITERATIONS)
			result = true;
		
		// checking if the centroids are same, i.e., checking for convergence
		for(int i=0;i<centroids.length;i++)
			if(centroids[i] != oldCentroids[i])
			{
				result = false;
				break;
			}
		return result;
	}
	
	private int[] getLabels(float[] data, float[] centroids){
		int[] labels = new int[centroids.length];
		
		// calculating to which centroid each data element belongs to
		for(int i=0;i<data.length;i++){
			
			float minDist=0;
			int minCentroid=0;
			
			for(int j=0;j<centroids.length;j++){
				float dist = (data[i] - centroids[j]) * (data[i] - centroids[j]);
				
				if(j==0){
					minDist = dist;
					minCentroid = j;
					continue;
				}
				if(dist< minDist){
					minDist = dist;
					minCentroid = j;
				}					
			}
			
			labels[i] = minCentroid;
		}
		return labels;
	}
	
	private float[] getCentroids(float[] data, int[] labels, int k){
		float centroids[] = new float[k];
		
		for(int i=0;i<k;i++){
			
			int pointsInCluster = 0;
			int sumOfCluster = 0;
			for(int j=0;j<data.length;j++){
				if(labels[i] == j){
					pointsInCluster++;
					sumOfCluster += data[i];
				}
			}
			
			centroids[i] = (float)sumOfCluster/pointsInCluster;
				
		}
		return centroids;
	}
	private float[] kmeans(float data[], int k){
		float[] centroids = getRandomCentroids(data,k);
		
		int iterations = 0;
		float[] oldCentroids = new float[k];
		int[] labels = new int[k];
		
		while(!shouldStop(oldCentroids, centroids, iterations)){
			oldCentroids = centroids;
			iterations++;
			
			labels = getLabels(data,centroids);
			centroids = getCentroids(data, labels, k);
		}
		
		return centroids;
	}
	

}


public class Perceptron1 {

}

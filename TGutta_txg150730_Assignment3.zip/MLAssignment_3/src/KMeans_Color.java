/*** Author :Vibhav Gogate
The University of Texas at Dallas
*****/

/**
 * @author Tapasya
 * The class is to test K-Means algorithm for a dataset 
 * Input: Dataset, number of clusters 'k'
 * Output: Mean of the clusters
 */

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.imageio.ImageIO;
 

public class KMeans_Color {
	
	final static int MAX_ITERATIONS = 50;
    public static void main(String [] args){
	if (args.length < 3){
	    System.out.println("Usage: Kmeans <input-image> <k> <output-image>");
	    return;
	}
	try{
	    BufferedImage originalImage = ImageIO.read(new File(args[0]));
	    int k=Integer.parseInt(args[1]);
	    BufferedImage kmeansJpg = kmeans_helper(originalImage,k);
	    ImageIO.write(kmeansJpg, "jpg", new File(args[2])); 
	    
	}catch(IOException e){
	    System.out.println(e.getMessage());
	}	
    }
    
    private static BufferedImage kmeans_helper(BufferedImage originalImage, int k){
    	int w=originalImage.getWidth();
    	int h=originalImage.getHeight();
    	BufferedImage kmeansImage = new BufferedImage(w,h,originalImage.getType());
    	Graphics2D g = kmeansImage.createGraphics();
    	g.drawImage(originalImage, 0, 0, w,h , null);
	
    	// Read rgb values from the image
    	System.out.println("Accquiring rbg values of the image");
    	int[] rgb=new int[w*h];
    	int count=0;
    	for(int i=0;i<w;i++){
    		for(int j=0;j<h;j++){
    			rgb[count++]=kmeansImage.getRGB(i,j);
    		}
    	}
	
    	/*for(int i=0;i<rgb.length;i++)
    		System.out.println(i + " - " + rgb[i]);*/
	
    	// Call kmeans algorithm: update the rgb values
    	System.out.println("Segmenting the image.");
    	rgb = kmeans(rgb,k);

	
    	// Write the new rgb values to the image
    	count=0;
    	for(int i=0;i<w;i++){
    		for(int j=0;j<h;j++){
    			kmeansImage.setRGB(i,j,rgb[count++]);
    		}
    	}
	
    	System.out.println("Image formed!");
    	return kmeansImage;
    }

	private static int[] getRandomMeans(int[] data,int k){
		int[] means = new int[k];
		
		int min = 0; // used to generate a random number
		int max = data.length - 1; // used to generate a random number
		int random;
		for(int i=0;i<k;i++){
			random = min + (int)(Math.random() * (max-min + 1));
			means[i] = random;
		}
		return means;
	}
	
	private static boolean shouldStop(int[] oldMeans, int[] means, int iterations){
		boolean result = true;
		
		// checking it number of iterations have exceeded the max interations allowed
		if(iterations > MAX_ITERATIONS)
			return true;
		
		// checking if the centroids are same, i.e., checking for convergence
		for(int i=0;i<means.length;i++){
			//System.out.println(means[i] + " " + oldMeans[i]);
			if(means[i] != oldMeans[i])
			{
				result = false;
				break;
			}
		}
		return result;
	}
	
	private static int[] assignLabels(int[] data, int[] means){
		int[] labels = new int[data.length];
		
		Color decodeColor;
		// calculating to which centroid each data element belongs to
		for(int i=0;i<data.length;i++){
			
			int minDist=0;
			int minMean=0;
			
			decodeColor = new Color(data[i]);
    		int blueValue = decodeColor.getBlue();
    		int greenValue = decodeColor.getGreen();
    		int redValue = decodeColor.getRed();
    		
			for(int j=0;j<means.length;j++){
				int dist = Math.abs(data[i] - means[j]) ;
				//int dist = (data[i] - means[j]) * (data[i] - means[j]);
				//int dist = (int)Math.sqrt((data[i] - means[j]) * (data[i] - means[j]));
				/*int blueDist = Math.abs(blueValue - means[j]) ;
				int redDist = Math.abs(redValue - means[j]) ;
				int greenDist = Math.abs(greenValue - means[j]) ;*/
				
				if(j==0){
					minDist = dist;
					minMean = j; 
					continue;
				}
				if(dist< minDist){
					minDist = dist;
					minMean = j;
				}					
			}
			
			labels[i] = minMean;
		}
		return labels;
	}
	
	private static int[] getMeans(int[] data, int[] labels, int k){
		int means[] = new int[k];
		
		for(int i=0;i<k;i++){			
			int pointsInCluster = 0;
			long sumOfCluster = 0;
			for(int j=0;j<data.length;j++){
				if(labels[j] == i){
					pointsInCluster++;
					sumOfCluster = sumOfCluster + data[j];
				}
			}
			if(pointsInCluster == 0)
				means[i] = 0;
			else
				means[i] = (int)(sumOfCluster/pointsInCluster);				
		}
		return means;
	}
	
    // Your k-means code goes here
    // Update the array rgb by assigning each entry in the rgb array to its cluster center
    private static int[] kmeans(int[] rgb, int k){
    	
    	// extracting the red, green and blue values from rgb
    	Color decodeColor;
    	int[] blueValues = new int[rgb.length];
    	int[] greenValues = new int[rgb.length];
    	int[] redValues = new int[rgb.length];
    	
    	for(int i=0;i<rgb.length;i++){
    		decodeColor = new Color(rgb[i]);
    		blueValues[i] = decodeColor.getBlue();
    		greenValues[i] = decodeColor.getGreen();
    		redValues[i] = decodeColor.getRed();
    	}
    	
    	// extracting the randoms mean values for each color value
    	int[] blueMeans = getRandomMeans(blueValues,k);
    	int[] greenMeans = getRandomMeans(greenValues,k);
    	int[] redMeans = getRandomMeans(redValues,k);
		
    	// declaring arrays for each color to store the old mean values
    	int[] oldBlueMeans = new int[k];
    	int[] oldGreenMeans = new int[k];
    	int[] oldRedMeans = new int[k];
    	
    	// declaring arrays to assign labels for each color type
    	int[] blueLabels = new int[rgb.length];
    	int[] greenLabels = new int[rgb.length];
    	int[] redLabels = new int[rgb.length];
    	
		int iterations = 0;
		int[] oldMeans = new int[k];
		int[] means = getRandomMeans(rgb, k);
		int[] labels = new int[rgb.length];
		
		
		while(!shouldStop(oldBlueMeans, blueMeans, iterations) && !shouldStop(oldGreenMeans, greenMeans, iterations) 
				&& !shouldStop(oldRedMeans, redMeans, iterations)){
			//System.out.println("Iteration : " + iterations);
			/*oldMeans = means;
			iterations++;
			
			labels = assignLabels(rgb,means);
			means = getMeans(rgb, labels, k);*/
			
			//blue
			oldBlueMeans = blueMeans;
			blueLabels = assignLabels(blueValues, blueMeans);
			blueMeans = getMeans(blueValues, blueLabels, k);
			
			//green
			oldGreenMeans = greenMeans;
			greenLabels = assignLabels(greenValues, greenMeans);
			greenMeans = getMeans(greenValues, greenLabels, k);
			
			//red
			oldRedMeans = redMeans;
			redLabels = assignLabels(redValues, redMeans);
			redMeans = getMeans(redValues, redLabels, k);
			 
		}
		
		for(int i=0;i<labels.length;i++){
			int blueClusterNo = blueLabels[i];
			int greenClusterNo = greenLabels[i];
			int redClusterNo = redLabels[i];
			
			int blueValue = (int)blueMeans[blueClusterNo];
			int greenValue = (int)greenMeans[greenClusterNo];
			int redValue = (int)redMeans[redClusterNo];
			
			// Getting the rgb value
			Color formColor = new Color(blueValue, greenValue, redValue);
			rgb[i] = formColor.getRGB();
			
			//rgb[i] = (int)means[meanNo];
			//System.out.println(i + " - " + centroidNo + " - " + rgb[i]);
		}
		
		/*for(int i=0;i<means.length;i++)
				System.out.println(i + " " + means[i]);*/
		return rgb;
    }

}
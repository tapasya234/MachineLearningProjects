
public class Perceptrontrain {

}

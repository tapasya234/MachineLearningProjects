import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class KMeans_Testing {

	private int MAX_ITERATIONS;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		KMeans_Testing obj = new KMeans_Testing();
		obj.MAX_ITERATIONS = 100;
		File f = new File("crime_data.csv");
		float data[] = obj.extractData(f);
		
		//float data[] = {1.0f, 1.5f, 3.0f, 5.0f, 3.5f, 4.5f, 3.5f};
		
		/*System.out.println("Random Centroids: ");
		float[] random = {3.0f, 1.0f};//obj.getRandomCentroids(data, 2);
		for(int i=0;i<random.length;i++)
			System.out.println(random[i]);
		
		System.out.println("Labels: ");
		int[] label = obj.getLabels(data, random);
		for(int i=0;i<label.length;i++)
			System.out.println(data[i] + " - " + label[i]);
		
		System.out.println("Centroids: ");
		float[] centroids = obj.getCentroids(data, label, 2);
		for(int i=0;i<centroids.length;i++)
			System.out.println(centroids[i]);*/
		
		
		float centroids[] = obj.kmeans(data,5);
		for(int i=0;i<centroids.length;i++)
			System.out.println(centroids[i]);
		
		
	}
	
	private float[] extractData(File f){
		float[] data = new float[50];
		
		FileReader fR;
		BufferedReader bR ;
		try {
			fR = new FileReader(f);
			bR = new BufferedReader(fR);
			
			bR.readLine();
			String line;
			
			int count=0;
			while((line = bR.readLine())!= null){
				String wordsInLine[] = line.split(",");
				data[count++] = Float.parseFloat(wordsInLine[wordsInLine.length-1]);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return data;
	}
	
	private float[] getRandomCentroids(float[] data,int k){
		float[] centroids = new float[k];
		
		int min = 0; // used to generate a random number
		int max = data.length - 1; // used to generate a random number
		int random;
		for(int i=0;i<k;i++){
			random = min + (int)(Math.random() * (max-min + 1));
			centroids[i] = random;
		}
		return centroids;
	}
	
	private boolean shouldStop(float[] oldCentroids, float[] centroids, int iterations){
		boolean result = true;
		
		// checking it number of iterations have exceeded the max interations allowed
		if(iterations > MAX_ITERATIONS)
			result = true;
		
		// checking if the centroids are same, i.e., checking for convergence
		for(int i=0;i<centroids.length;i++){
			if(centroids[i] != oldCentroids[i])
			{
				result = false;
				break;
			}
		}
		
		return result;
	}
	
	private int[] getLabels(float[] data, float[] centroids){
		int[] labels = new int[data.length];
		
		// calculating to which centroid each data element belongs to
		for(int i=0;i<data.length;i++){
			
			float minDist=0;
			int minCentroid=0;
			
			for(int j=0;j<centroids.length;j++){
				float dist = /*Math.abs(*/(data[i] - centroids[j]) * (data[i] - centroids[j]);
				
				if(j==0){
					minDist = dist;
					minCentroid = j;
					continue;
				}
				if(dist < minDist){
					minDist = dist;
					minCentroid = j;
				}					
			}
			
			labels[i] = minCentroid;
		}
		return labels;
	}
	
	private float[] getCentroids(float[] data, int[] labels, int k){
		float centroids[] = new float[k];
		
		for(int i=0;i<k;i++){
			
			int pointsInCluster = 0;
			float sumOfCluster = 0;
			System.out.println("Cluster: " + i);
			for(int j=0;j<data.length;j++){
				if(labels[j] == i){
					pointsInCluster++;
					sumOfCluster += data[j];
				}
			}
			
			centroids[i] = (float)sumOfCluster/pointsInCluster;
				
		}
		return centroids;
	}
	private float[] kmeans(float data[], int k){
		float[] centroids = getRandomCentroids(data,k);
		
		for(int i=0;i<k;i++)
			System.out.println(centroids[i]);
		int iterations = 0;
		float[] oldCentroids = new float[k];
		int[] labels = new int[k];
		
		while(!shouldStop(oldCentroids, centroids, iterations)){
			System.out.println("Iteration Number: " + iterations);
			oldCentroids = centroids;
			iterations++;
			
			labels = getLabels(data,centroids);
			centroids = getCentroids(data, labels, k);
		}
		
		return centroids;
	}
}

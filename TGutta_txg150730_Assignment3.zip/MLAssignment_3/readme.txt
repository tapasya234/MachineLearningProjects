Files included: 
train folder -> Contains all the ham and spam files need to train the classifier algorithm

test folder -> Contains all the ham and spam files needed to test the trained classifier.

src folder -> KMeans.java; KMeans_Color.java; Perceptron.java; 

Perceptron.java -> This file goes through all the files in the train folder to train the classifier using the Perceptron algorithm and then goes through the test folder to predict the class of each document in that folder. Then it does the same thing all over again by not considering the stop words
Input - none
Output - accuracy of the algorithm

Kmeans.java -> This file takes the name of an image as parameter, segmentes the image using K Means algorithm and generates a new image that is segmented.
Input - <image_name> <k> <output_image>
Output - <output_image>